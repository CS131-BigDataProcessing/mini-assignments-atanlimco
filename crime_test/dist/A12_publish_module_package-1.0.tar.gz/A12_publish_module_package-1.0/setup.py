from setuptools import setup, find_packages
setup(
name='A12_publish_module_package',
version='1.0',
packages=find_packages(), 
install_requires=[], # there are no dependencies needd
description='Package to validate Vict Age and Vict Sex and calculate mean and median for Vict Age',
author='Averi Tanlimco',
author_email='averi.tanlimco@sjsu.edu'
)
